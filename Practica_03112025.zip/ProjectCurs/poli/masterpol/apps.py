from django.apps import AppConfig


class MasterpolConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'masterpol'
